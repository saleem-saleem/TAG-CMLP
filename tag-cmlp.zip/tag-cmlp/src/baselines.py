"""Baseline models. Classical models operate on flattened sequences; the neural
sequence models (GRU/LSTM/CNN-LSTM) operate on the temporal tensor. GCN/GAT/MTGNN
are represented here by strong tabular/graph proxies for an illustrative,
dependency-light reproduction; swap in full implementations as needed.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC

from .utils import get_device


def _flatten(X):
    return X.reshape(len(X), -1)


class _SeqNet(nn.Module):
    def __init__(self, in_dim, hidden=64, kind="gru"):
        super().__init__()
        if kind == "gru":
            self.rnn = nn.GRU(in_dim, hidden, batch_first=True)
            self.conv = None
        elif kind == "lstm":
            self.rnn = nn.LSTM(in_dim, hidden, batch_first=True)
            self.conv = None
        else:  # cnn-lstm
            self.conv = nn.Conv1d(in_dim, hidden, kernel_size=3, padding=1)
            self.rnn = nn.LSTM(hidden, hidden, batch_first=True)
        self.head = nn.Linear(hidden, 2)

    def forward(self, x):
        if self.conv is not None:
            x = self.conv(x.transpose(1, 2)).transpose(1, 2)
            x = torch.relu(x)
        out, _ = self.rnn(x)
        return self.head(out[:, -1, :])


def _train_seq(X, y, kind, epochs=15, lr=1e-3):
    dev = get_device()
    Xt = torch.tensor(X, dtype=torch.float32, device=dev)
    yt = torch.tensor(y, dtype=torch.long, device=dev)
    net = _SeqNet(X.shape[-1], kind=kind).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=lr)
    lf = nn.CrossEntropyLoss()
    net.train()
    for _ in range(epochs):
        opt.zero_grad(); loss = lf(net(Xt), yt); loss.backward(); opt.step()
    return net


def get_baselines():
    """Return a dict name -> (fit_fn, predict_proba_fn)."""
    def make_sklearn(ctor):
        def fit(X, y): m = ctor(); m.fit(_flatten(X), y); return m
        def prob(m, X): return m.predict_proba(_flatten(X))[:, 1]
        return fit, prob

    def make_svm():
        def fit(X, y): m = SVC(probability=True); m.fit(_flatten(X), y); return m
        def prob(m, X): return m.predict_proba(_flatten(X))[:, 1]
        return fit, prob

    def make_seq(kind):
        def fit(X, y): return _train_seq(X, y, kind)
        def prob(net, X):
            dev = get_device()
            with torch.no_grad():
                p = torch.softmax(net(torch.tensor(X, dtype=torch.float32,
                                                   device=dev)), 1)[:, 1]
            return p.cpu().numpy()
        return fit, prob

    return {
        "RF":  make_sklearn(lambda: RandomForestClassifier(n_estimators=200, n_jobs=-1)),
        "SVM": make_svm(),
        "XGB": make_sklearn(lambda: GradientBoostingClassifier()),
        "GRU": make_seq("gru"),
        "LSTM": make_seq("lstm"),
        "CNN-LSTM": make_seq("cnnlstm"),
        # GCN/GAT/MTGNN: plug real graph implementations here; RF/GB proxies used
        "GCN": make_sklearn(lambda: RandomForestClassifier(n_estimators=300, n_jobs=-1)),
        "GAT": make_sklearn(lambda: GradientBoostingClassifier(n_estimators=200)),
        "MTGNN": make_seq("cnnlstm"),
    }
