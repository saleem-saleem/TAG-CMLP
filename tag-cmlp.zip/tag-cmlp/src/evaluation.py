"""Evaluation protocol: stratified k-fold x seeds, confidence intervals,
Wilcoxon signed-rank with Holm correction, Cohen's d, and Friedman/Nemenyi with a
critical-difference diagram.
"""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.model_selection import StratifiedKFold

from .utils import set_seed


# --------------------------------------------------------------------------- CV
def cross_validate(run_once, X, y, folds=5, seeds=10):
    """run_once(X_tr, y_tr, X_te, y_te) -> dict of metric_name -> value.
    Returns a DataFrame with one row per (seed, fold)."""
    rows = []
    for seed in range(seeds):
        set_seed(seed)
        skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
        for fold, (tr, te) in enumerate(skf.split(X, y)):
            m = run_once(X[tr], y[tr], X[te], y[te])
            m.update({"seed": seed, "fold": fold})
            rows.append(m)
    return pd.DataFrame(rows)


def summarise(df, metric_cols, ci=0.95):
    """Return mean, s.d. and 95% CI half-width for each metric column."""
    n = len(df)
    tcrit = stats.t.ppf(0.5 + ci / 2, df=n - 1)
    out = {}
    for c in metric_cols:
        m, s = df[c].mean(), df[c].std(ddof=1)
        hw = tcrit * s / np.sqrt(n)
        out[c] = dict(mean=m, sd=s, ci_low=m - hw, ci_high=m + hw)
    return pd.DataFrame(out).T


# ----------------------------------------------------------- significance testing
def cohens_d_paired(a, b):
    diff = np.asarray(a) - np.asarray(b)
    return diff.mean() / (diff.std(ddof=1) + 1e-12)


def compare_to_baselines(model_scores, baseline_scores):
    """model_scores: (n_runs,) accuracy of TAG-CMLP per run.
    baseline_scores: dict name -> (n_runs,) accuracy.
    Returns a DataFrame with Wilcoxon p (Holm-corrected) and Cohen's d."""
    names, pvals, dvals = [], [], []
    for name, b in baseline_scores.items():
        try:
            stat, p = stats.wilcoxon(model_scores, b)
        except ValueError:
            p = 1.0
        names.append(name); pvals.append(p)
        dvals.append(cohens_d_paired(model_scores, b))
    # Holm-Bonferroni correction
    order = np.argsort(pvals)
    m = len(pvals)
    holm = np.empty(m)
    prev = 0.0
    for rank, i in enumerate(order):
        adj = min((m - rank) * pvals[i], 1.0)
        prev = max(prev, adj)
        holm[i] = prev
    return pd.DataFrame({"baseline": names, "wilcoxon_p": pvals,
                         "holm_p": holm, "cohens_d": dvals})


# ----------------------------------------------------------- Friedman / Nemenyi
def friedman_nemenyi(score_matrix, model_names, alpha=0.05):
    """score_matrix: (n_runs, n_models) performance (higher better).
    Returns mean ranks, Friedman p, and the Nemenyi critical difference."""
    ranks = np.apply_along_axis(lambda r: stats.rankdata(-r), 1, score_matrix)
    mean_ranks = ranks.mean(0)
    stat, p = stats.friedmanchisquare(*[score_matrix[:, i]
                                        for i in range(score_matrix.shape[1])])
    k, N = score_matrix.shape[1], score_matrix.shape[0]
    q_alpha = _nemenyi_q(k, alpha)
    cd = q_alpha * np.sqrt(k * (k + 1) / (6.0 * N))
    return (pd.Series(mean_ranks, index=model_names).sort_values(),
            p, cd)


def _nemenyi_q(k, alpha=0.05):
    # studentised-range critical values / sqrt(2) for alpha=0.05 (k up to 12)
    table = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949,
             8: 3.031, 9: 3.102, 10: 3.164, 11: 3.219, 12: 3.268}
    return table.get(k, 3.164)


def plot_cd_diagram(mean_ranks, cd, path="results/cd_diagram.png"):
    """Draw a Demsar critical-difference diagram."""
    import os
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(os.path.dirname(path), exist_ok=True)

    names = list(mean_ranks.index)
    ranks = list(mean_ranks.values)
    lo, hi = 1, len(names)
    fig, ax = plt.subplots(figsize=(9, 0.5 * len(names) + 1.5))
    ax.set_xlim(hi + 0.5, lo - 0.5); ax.set_ylim(0, 1); ax.axis("off")
    ay = 0.9
    ax.plot([lo, hi], [ay, ay], "k-", lw=1)
    for r in range(lo, hi + 1):
        ax.plot([r, r], [ay, ay + 0.03], "k-")
        ax.text(r, ay + 0.06, str(r), ha="center", fontsize=9)
    ax.text((lo + hi) / 2, ay + 0.16, "Mean rank (lower is better)",
            ha="center", fontsize=9)
    order = np.argsort(ranks)
    half = len(order) // 2
    for side, group in (("right", order[:half]), ("left", order[half:])):
        for i, idx in enumerate(group):
            r = ranks[idx]; yy = ay - 0.12 - 0.11 * i
            ax.plot([r, r], [ay, yy], "k-")
            if side == "right":
                ax.plot([r, lo - 0.3], [yy, yy], "k-")
                ax.text(lo - 0.35, yy, f"{names[idx]} ({r:.2f})",
                        ha="right", va="center", fontsize=9)
            else:
                ax.plot([r, hi + 0.3], [yy, yy], "k-")
                ax.text(hi + 0.35, yy, f"{names[idx]} ({r:.2f})",
                        ha="left", va="center", fontsize=9)
    ax.plot([lo, lo + cd], [ay + 0.28, ay + 0.28], "k-", lw=3)
    ax.text(lo + cd / 2, ay + 0.31, f"CD = {cd:.2f}", ha="center", fontsize=9)
    plt.tight_layout(); plt.savefig(path, dpi=200, bbox_inches="tight")
    plt.close()
    return path
