"""Stage II - Graph-based Adaptive Influence Learning (GAIL).

Builds a *student*-similarity graph from the TFEM embeddings (nodes = students,
edges = above-threshold cosine similarity), applies a light graph convolution,
computes the Peer Learning Influence Score, then trains a small ensemble of base
learners whose outputs are combined by a reliability-weighted average.

  S_ij   = cosine(z_i, z_j)                                        (Eq. 13)
  A_ij   = 1 if S_ij > epsilon                                     (Eq. 14)
  PLIS_i = sum_{j in N(i)} S_ij * exp(-||z_i - z_j||)              (Eq. 18)
  z_i'   = z_i + eta * PLIS_i * mean_j(z_j)                        (Eq. 19)
  R_k    = Acc_k * (1 - ECE_k) / (1 + Var_k)                       (Eq. 21)
  w_k    = R_k / sum_j R_j                                         (Eq. 22)
"""
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

from ..metrics import expected_calibration_error


def build_similarity_graph(z, threshold=0.5, knn=15):
    """Return sparse neighbour lists and cosine similarities (kNN-capped)."""
    zn = z / (np.linalg.norm(z, axis=1, keepdims=True) + 1e-8)
    k = min(knn + 1, len(z))
    nn = NearestNeighbors(n_neighbors=k, metric="cosine").fit(zn)
    dist, idx = nn.kneighbors(zn)
    sim = 1.0 - dist
    neigh, sims = [], []
    for i in range(len(z)):
        j = idx[i][1:]                       # drop self
        s = sim[i][1:]
        mask = s > threshold
        neigh.append(j[mask]); sims.append(s[mask])
    return neigh, sims, zn


def graph_refine(z, cfg):
    """One graph-convolution + PLIS update step. Returns refined embeddings."""
    neigh, sims, zn = build_similarity_graph(z, cfg["sim_threshold"], cfg["knn"])
    z_new = z.copy()
    for i in range(len(z)):
        j, s = neigh[i], sims[i]
        if len(j) == 0:
            continue
        # graph convolution: similarity-weighted neighbour mean
        w = s / (s.sum() + 1e-8)
        agg = (w[:, None] * z[j]).sum(0)
        # PLIS (Eq. 18): couple similarity with embedding-distance decay
        dist = np.linalg.norm(z[i] - z[j], axis=1)
        plis = float((s * np.exp(-dist)).sum())
        z_new[i] = z[i] + cfg["eta"] * plis * agg    # Eq. 19 (illustrative)
    return z_new


def _base_learners():
    return {
        "lr":  LogisticRegression(max_iter=500),
        "rf":  RandomForestClassifier(n_estimators=200, n_jobs=-1),
        "gb":  GradientBoostingClassifier(),
    }


def fit_gail(z_train, y_train, z_val, y_val, cfg):
    """Train base learners on graph-refined embeddings; return them and their
    reliability weights (Eqs. 21-22)."""
    zt = graph_refine(z_train, cfg)
    learners, R = {}, {}
    for name, clf in _base_learners().items():
        clf.fit(zt, y_train)
        p = clf.predict_proba(graph_refine(z_val, cfg))[:, 1]
        acc = ((p > 0.5).astype(int) == y_val).mean()
        ece = expected_calibration_error(y_val, p, cfg.get("ece_bins", 10))
        var = np.var(p)                                     # predictive variance
        R[name] = acc * (1 - ece) / (1 + var)               # Eq. 21
        learners[name] = clf
    tot = sum(R.values()) + 1e-8
    w = {k: R[k] / tot for k in R}                          # Eq. 22
    return learners, w


def predict_gail(learners, w, z, cfg):
    """Return per-learner probability matrix P (n, K) and ensemble prob (n,)."""
    zr = graph_refine(z, cfg)
    P = np.stack([learners[k].predict_proba(zr)[:, 1] for k in learners], axis=1)
    weights = np.array([w[k] for k in learners])
    ens = (P * weights).sum(1)
    return P, ens
