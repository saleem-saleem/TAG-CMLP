"""Stage I - Temporal Feature Evolution Modeling (TFEM).

Standard temporal attention augmented with two stability-aware quantities:
  TAES_i = sum_{t>=2} alpha_t * || x_i^t - x_i^{t-1} ||^2         (Eq. 8)
  TS_i   = (1/T) sum_t || x_i^t - mean_t(x_i) ||^2                (Eq. 9)
  z_i    = h_i + lambda1 * TAES_i * u - lambda2 * TS_i * v        (Eq. 10)

h_i is the attention-pooled representation (Eq. 7); u, v are learnable directions
that broadcast the scalar TAES/TS scores into the embedding space.
"""
import numpy as np
import torch
import torch.nn as nn


class TFEM(nn.Module):
    def __init__(self, in_dim, embed_dim=64, attn_dim=64, lambda1=0.30, lambda2=0.20):
        super().__init__()
        self.proj = nn.Linear(in_dim, embed_dim)
        self.attn_w = nn.Linear(embed_dim, attn_dim)
        self.attn_v = nn.Linear(attn_dim, 1, bias=False)
        self.u = nn.Parameter(torch.randn(embed_dim) * 0.01)   # TAES direction
        self.v = nn.Parameter(torch.randn(embed_dim) * 0.01)   # TS direction
        self.lambda1, self.lambda2 = lambda1, lambda2
        self.out = nn.Linear(embed_dim, embed_dim)

    def forward(self, x):                       # x: (N, T, in_dim)
        e = torch.tanh(self.proj(x))            # (N, T, D)
        scores = self.attn_v(torch.tanh(self.attn_w(e))).squeeze(-1)   # (N, T)
        alpha = torch.softmax(scores, dim=1)                          # Eq. 6
        h = (alpha.unsqueeze(-1) * e).sum(1)                          # Eq. 7 -> (N, D)

        # TAES (Eq. 8): attention-weighted step-to-step change
        diff = (e[:, 1:, :] - e[:, :-1, :]).pow(2).sum(-1)           # (N, T-1)
        taes = (alpha[:, 1:] * diff).sum(1)                          # (N,)

        # TS (Eq. 9): dispersion around the temporal mean
        mean = e.mean(1, keepdim=True)
        ts = (e - mean).pow(2).sum(-1).mean(1)                       # (N,)

        # normalise the scalar scores for stable scaling
        taes = (taes - taes.mean()) / (taes.std() + 1e-6)
        ts = (ts - ts.mean()) / (ts.std() + 1e-6)

        z = h + self.lambda1 * taes.unsqueeze(-1) * self.u \
              - self.lambda2 * ts.unsqueeze(-1) * self.v            # Eq. 10
        return self.out(z)


def fit_tfem(X, y, cfg, device="cpu"):
    """Train TFEM with a light classification head and return embeddings z (numpy)."""
    from ..utils import set_seed
    Xt = torch.tensor(X, dtype=torch.float32, device=device)
    yt = torch.tensor(y, dtype=torch.long, device=device)
    model = TFEM(X.shape[-1], cfg["embed_dim"], cfg["attn_dim"],
                 cfg["lambda1"], cfg["lambda2"]).to(device)
    head = nn.Linear(cfg["embed_dim"], 2).to(device)
    opt = torch.optim.Adam(list(model.parameters()) + list(head.parameters()),
                           lr=cfg["lr"])
    lossf = nn.CrossEntropyLoss()
    model.train()
    for _ in range(cfg["epochs"]):
        opt.zero_grad()
        z = model(Xt)
        loss = lossf(head(z), yt)
        loss.backward()
        opt.step()
    model.eval()
    with torch.no_grad():
        z = model(Xt).cpu().numpy()
    return z
