"""Full TAG-CMLP pipeline: TFEM -> GAIL -> CUDM."""
import numpy as np

from .tfem import fit_tfem
from .gail import fit_gail, predict_gail
from .cudm import fit_corrector, apply_cudm
from ..utils import get_device


class TAGCMLP:
    def __init__(self, cfg):
        self.cfg = cfg
        self.device = get_device()

    def fit(self, X_train, y_train, X_val, y_val):
        # Stage I: raw sequences -> embeddings
        self.z_tr = fit_tfem(X_train, y_train, self.cfg["tfem"], self.device)
        self.z_val = fit_tfem(X_val, y_val, self.cfg["tfem"], self.device)
        # Stage II: embeddings -> base learners + reliability weights
        self.learners, self.w = fit_gail(self.z_tr, y_train, self.z_val, y_val,
                                          self.cfg["gail"])
        # Stage III: meta-corrector for high-risk cases
        self.corrector = fit_corrector(self.z_tr, y_train)
        return self

    def predict(self, X_test, y_test=None):
        z_te = fit_tfem(X_test, y_test if y_test is not None
                        else np.zeros(len(X_test), int),
                        self.cfg["tfem"], self.device)
        P, ens = predict_gail(self.learners, self.w, z_te, self.cfg["gail"])
        pred, prob, cri, rel = apply_cudm(P, ens, z_te, self.cfg["cudm"],
                                          self.corrector)
        return dict(pred=pred, prob=prob, cri=cri, rel=rel)
