"""Stage III - Confidence-aware Uncertainty Decision Module (CUDM).

From the base-learner probabilities it computes three per-sample signals and the
Cognitive Risk Index, then selectively corrects only the high-risk predictions.

  H(x) : normalised predictive entropy                             (Eq. 24)
  M(x) : top-two probability margin                                (Eq. 25)
  D(x) : inter-model disagreement (std across learners)            (Eq. 26)
  CRI  = lH*H + lM*(1 - M) + lD*D   (min-max normalised)           (Eq. 27)
  accept if CRI <= theta, else route to the meta-corrector
  REL  = 100 * mean(1 - CRI_norm)                                  (Eq. 30)
"""
import numpy as np
from sklearn.linear_model import LogisticRegression


def _entropy(p):
    p = np.clip(np.stack([1 - p, p], axis=1), 1e-8, 1)
    return (-(p * np.log(p)).sum(1)) / np.log(2)             # normalised to [0,1]


def compute_cri(P, ens, cfg):
    """Return CRI in [0,1] plus its components, given per-learner probs P (n,K)."""
    H = _entropy(ens)                                        # Eq. 24
    two = np.sort(np.stack([1 - ens, ens], axis=1), axis=1)[:, ::-1]
    M = two[:, 0] - two[:, 1]                                # Eq. 25 (top-two margin)
    D = P.std(axis=1)                                        # Eq. 26
    cri = cfg["lambda_H"] * H + cfg["lambda_M"] * (1 - M) + cfg["lambda_D"] * D
    cri = (cri - cri.min()) / (cri.max() - cri.min() + 1e-8)
    return cri, H, M, D


def fit_corrector(z_train, y_train):
    """A simple meta-corrector trained on the embeddings (illustrative)."""
    clf = LogisticRegression(max_iter=500)
    clf.fit(z_train, y_train)
    return clf


def apply_cudm(P, ens, z, cfg, corrector=None):
    """Return final predictions, the CRI, and the reliability metric REL."""
    cri, H, M, D = compute_cri(P, ens, cfg)
    pred = (ens > 0.5).astype(int)
    if corrector is not None:
        high_risk = cri > cfg["theta"]
        if high_risk.any():
            pred[high_risk] = corrector.predict(z[high_risk])
    rel = 100.0 * float(np.mean(1 - cri))                   # Eq. 30
    return pred, ens, cri, rel
