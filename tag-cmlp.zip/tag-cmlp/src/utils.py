"""Utility helpers: seeding, config loading, device selection."""
import os, random, yaml
import numpy as np


def load_config(path="config.yaml"):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def set_seed(seed):
    """Seed python, numpy and torch (if available) for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def get_device():
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"
