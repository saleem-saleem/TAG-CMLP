"""Evaluation metrics, including the reliability metric REL (Eq. 30) and ECE."""
import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)


def expected_calibration_error(y_true, prob, n_bins=10):
    """ECE = sum_b (|B_b|/n) * |acc(B_b) - conf(B_b)|."""
    bins = np.linspace(0, 1, n_bins + 1)
    ece, n = 0.0, len(y_true)
    pred = (prob > 0.5).astype(int)
    for b in range(n_bins):
        m = (prob > bins[b]) & (prob <= bins[b + 1])
        if m.sum() == 0:
            continue
        acc = (pred[m] == y_true[m]).mean()
        conf = prob[m].mean()
        ece += (m.sum() / n) * abs(acc - conf)
    return ece


def classification_metrics(y_true, pred, prob, rel=None):
    """Return the standard metrics plus REL (if supplied)."""
    out = {
        "ACC": accuracy_score(y_true, pred) * 100,
        "PRE": precision_score(y_true, pred, zero_division=0) * 100,
        "REC": recall_score(y_true, pred, zero_division=0) * 100,
        "F1":  f1_score(y_true, pred, zero_division=0) * 100,
        "AUC": roc_auc_score(y_true, prob) if len(set(y_true)) > 1 else float("nan"),
    }
    if rel is not None:
        out["REL"] = rel
    return out
