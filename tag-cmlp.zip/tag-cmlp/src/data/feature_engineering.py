"""Temporal feature engineering with explicit, causal early-prediction boundaries.

For an early-prediction cutoff at week w:
  * cumulative observation window  W_w = [0, 7w) days  (day 0 = presentation start)
  * partitioned into fixed bins of `bin_days` (default 6, cf. Table 9)
  * strictly causal: nothing with date >= 7w enters any feature
  * Pass/Withdrawn safeguard: a student is included only if still registered at
    week w (date_unregistration is NaN or >= 7w), preventing withdrawal-label
    leakage from the absence of post-withdrawal activity.
"""
import numpy as np
import pandas as pd

from .oulad_loader import ACTIVITY_TYPES


def make_labels(studentInfo, task):
    """Return (id_student array, binary label array) for the chosen task.

    task='pass_fail'      : Pass/Distinction -> 1, Fail -> 0 (Withdrawn dropped)
    task='pass_withdrawn' : Pass/Distinction -> 1, Withdrawn -> 0 (Fail dropped)
    """
    df = studentInfo[["id_student", "final_result"]].copy()
    if task == "pass_fail":
        df = df[df.final_result.isin(["Pass", "Distinction", "Fail"])]
        y = df.final_result.isin(["Pass", "Distinction"]).astype(int).values
    elif task == "pass_withdrawn":
        df = df[df.final_result.isin(["Pass", "Distinction", "Withdrawn"])]
        y = df.final_result.isin(["Pass", "Distinction"]).astype(int).values
    else:
        raise ValueError(task)
    return df.id_student.values, y


def build_sequences(data, task, cutoff_week, bin_days=6):
    """Build the temporal feature tensor for all eligible students at a cutoff.

    Returns
    -------
    ids : (N,)         student ids kept
    X   : (N, T, d)    per-student temporal sequence (T bins, d features)
    y   : (N,)         binary labels
    """
    cutoff_day = 7 * cutoff_week
    T = int(np.ceil(cutoff_day / bin_days))            # T_w = ceil(7w / bin_days)

    ids, y = make_labels(data["studentInfo"], task)
    reg = data["studentRegistration"].set_index("id_student")

    # ---- Pass/Withdrawn causal safeguard: keep only students active at week w ----
    if task == "pass_withdrawn":
        keep = []
        for sid in ids:
            unreg = reg.loc[sid, "date_unregistration"] if sid in reg.index else np.nan
            if np.isnan(unreg) or unreg >= cutoff_day:
                keep.append(True)
            else:
                keep.append(False)          # already withdrawn before cutoff -> exclude
        keep = np.array(keep)
        ids, y = ids[keep], y[keep]

    id_index = {sid: i for i, sid in enumerate(ids)}
    N = len(ids)

    # activity-type map for clicks
    vle = data["vle"].set_index("id_site")["activity_type"].to_dict()
    act_index = {a: k for k, a in enumerate(ACTIVITY_TYPES)}
    n_act = len(ACTIVITY_TYPES)
    d = n_act + 2                                       # + total_clicks + assess_score
    X = np.zeros((N, T, d), dtype=np.float32)

    # ---- clickstream, strictly before cutoff_day ----
    vle_df = data["studentVle"]
    vle_df = vle_df[(vle_df.date >= 0) & (vle_df.date < cutoff_day)]
    vle_df = vle_df[vle_df.id_student.isin(id_index)]
    for sid, sub in vle_df.groupby("id_student"):
        i = id_index[sid]
        for site, day, clk in zip(sub.id_site, sub.date, sub.sum_click):
            b = min(int(day) // bin_days, T - 1)
            a = act_index.get(vle.get(site, "resource"), 0)
            X[i, b, a] += clk
            X[i, b, n_act] += clk                       # total clicks channel

    # ---- assessment scores, strictly before cutoff_day ----
    sa = data["studentAssessment"].merge(
        data["assessments"][["id_assessment", "date"]], on="id_assessment", how="left")
    sa = sa[(sa.date_submitted >= 0) & (sa.date_submitted < cutoff_day)]
    sa = sa[sa.id_student.isin(id_index)]
    for sid, sub in sa.groupby("id_student"):
        i = id_index[sid]
        for day, score in zip(sub.date_submitted, sub.score):
            b = min(int(day) // bin_days, T - 1)
            X[i, b, n_act + 1] = max(X[i, b, n_act + 1], float(score) / 100.0)

    # log1p + per-feature standardisation (robust to the heavy-tailed click counts)
    X = np.log1p(X)
    mu = X.reshape(-1, d).mean(0)
    sd = X.reshape(-1, d).std(0) + 1e-6
    X = (X - mu) / sd
    return ids, X, y.astype(int)
