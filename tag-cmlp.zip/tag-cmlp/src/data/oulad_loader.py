"""Load the seven OULAD tables, or generate a synthetic dataset with the same
schema when the real data is not present (so the pipeline runs end-to-end).

OULAD source tables (fields used):
  studentInfo         gender, region, highest_education, imd_band, age_band,
                      num_of_prev_attempts, studied_credits, disability, final_result
  studentRegistration date_registration, date_unregistration
  studentVle          id_student, id_site, date, sum_click
  vle                 id_site, activity_type, week_from, week_to
  studentAssessment   id_assessment, id_student, date_submitted, score
  assessments         id_assessment, assessment_type, date, weight
  courses             code_module, code_presentation, module_presentation_length
"""
import os
import numpy as np
import pandas as pd

ACTIVITY_TYPES = ["resource", "oucontent", "forumng", "quiz", "url",
                  "homepage", "subpage"]
FINAL_RESULTS = ["Distinction", "Pass", "Fail", "Withdrawn"]


def _read(oulad_dir, name):
    return pd.read_csv(os.path.join(oulad_dir, f"{name}.csv"))


def load_oulad(oulad_dir="data/oulad", n_students=2000, length_days=273, seed=0):
    """Return a dict of DataFrames. Falls back to synthetic data if files absent."""
    needed = ["studentInfo", "studentRegistration", "studentVle", "vle",
              "studentAssessment", "assessments", "courses"]
    if all(os.path.exists(os.path.join(oulad_dir, f"{n}.csv")) for n in needed):
        return {n: _read(oulad_dir, n) for n in needed}
    print("[oulad_loader] real OULAD not found -> generating synthetic data "
          f"({n_students} students).")
    return _synthetic(n_students=n_students, length_days=length_days, seed=seed)


def _synthetic(n_students=2000, length_days=273, seed=0):
    rng = np.random.default_rng(seed)
    ids = np.arange(1, n_students + 1)

    # latent 'ability' drives both behaviour and outcome (so the task is learnable)
    ability = rng.normal(0, 1, n_students)

    # ---- studentInfo (+ label) ----
    logits = np.stack([
        ability * 1.2 + 0.4,          # Distinction
        ability * 0.8 + 0.9,          # Pass
        -ability * 0.9 + 0.3,         # Fail
        -ability * 0.6 - 0.2,         # Withdrawn
    ], axis=1)
    probs = np.exp(logits) / np.exp(logits).sum(1, keepdims=True)
    final = np.array([rng.choice(FINAL_RESULTS, p=p) for p in probs])
    studentInfo = pd.DataFrame({
        "id_student": ids,
        "gender": rng.choice(["M", "F"], n_students),
        "region": rng.choice([f"reg{i}" for i in range(10)], n_students),
        "highest_education": rng.choice(["HE", "A_Level", "Lower"], n_students),
        "imd_band": rng.choice([f"{i}0-{i}0%" for i in range(1, 10)], n_students),
        "age_band": rng.choice(["0-35", "35-55", "55<="], n_students),
        "num_of_prev_attempts": rng.integers(0, 3, n_students),
        "studied_credits": rng.integers(30, 240, n_students),
        "disability": rng.choice(["Y", "N"], n_students, p=[0.1, 0.9]),
        "final_result": final,
    })

    # ---- studentRegistration ----
    date_reg = -rng.integers(0, 60, n_students)
    # withdrawals get an unregistration date somewhere during the course
    date_unreg = np.where(
        final == "Withdrawn",
        rng.integers(20, length_days, n_students).astype(float),
        np.nan,
    )
    studentRegistration = pd.DataFrame({
        "id_student": ids,
        "date_registration": date_reg,
        "date_unregistration": date_unreg,
    })

    # ---- vle metadata ----
    n_sites = 60
    vle = pd.DataFrame({
        "id_site": np.arange(1, n_sites + 1),
        "activity_type": rng.choice(ACTIVITY_TYPES, n_sites),
        "week_from": rng.integers(0, 30, n_sites),
        "week_to": rng.integers(30, 40, n_sites),
    })

    # ---- studentVle clickstream ----
    rows = []
    for sid, ab, fin, unreg in zip(ids, ability, final,
                                   studentRegistration.date_unregistration):
        last_day = int(unreg) if not np.isnan(unreg) else length_days
        base_rate = max(0.2, 1.5 + ab)            # more able -> more active
        n_events = rng.poisson(base_rate * last_day / 7)
        if n_events == 0:
            continue
        days = rng.integers(0, max(1, last_day), n_events)
        sites = rng.integers(1, n_sites + 1, n_events)
        clicks = rng.integers(1, 12, n_events)
        for d, s, ck in zip(days, sites, clicks):
            rows.append((sid, s, int(d), int(ck)))
    studentVle = pd.DataFrame(rows, columns=["id_student", "id_site", "date",
                                             "sum_click"])

    # ---- assessments + studentAssessment ----
    n_assess = 6
    assessments = pd.DataFrame({
        "id_assessment": np.arange(1, n_assess + 1),
        "assessment_type": rng.choice(["TMA", "CMA", "Exam"], n_assess),
        "date": np.linspace(30, length_days, n_assess).astype(int),
        "weight": rng.integers(5, 40, n_assess),
    })
    sa_rows = []
    for sid, ab, fin, unreg in zip(ids, ability, final,
                                   studentRegistration.date_unregistration):
        last_day = int(unreg) if not np.isnan(unreg) else length_days
        for aid, adate in zip(assessments.id_assessment, assessments.date):
            if adate > last_day:
                continue
            score = np.clip(60 + 15 * ab + rng.normal(0, 10), 0, 100)
            sa_rows.append((aid, sid, int(adate - rng.integers(0, 7)), float(score)))
    studentAssessment = pd.DataFrame(
        sa_rows, columns=["id_assessment", "id_student", "date_submitted", "score"])

    courses = pd.DataFrame({
        "code_module": ["AAA"], "code_presentation": ["2013J"],
        "module_presentation_length": [length_days],
    })

    return dict(studentInfo=studentInfo, studentRegistration=studentRegistration,
                studentVle=studentVle, vle=vle,
                studentAssessment=studentAssessment, assessments=assessments,
                courses=courses)
