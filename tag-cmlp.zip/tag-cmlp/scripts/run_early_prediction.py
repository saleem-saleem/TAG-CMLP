"""Early-prediction experiment: for each weekly cutoff, evaluate TAG-CMLP and all
baselines under 5-fold x 10-seed cross-validation, saving mean +/- s.d. tables and
the per-run scores used for significance testing.

Usage:
    python -m scripts.run_early_prediction --task pass_fail --config config.yaml
"""
import argparse, os
import numpy as np
import pandas as pd

from src.utils import load_config
from src.data.oulad_loader import load_oulad
from src.data.feature_engineering import build_sequences
from src.models.tag_cmlp import TAGCMLP
from src.baselines import get_baselines
from src.metrics import classification_metrics
from src.evaluation import cross_validate, summarise


def run_tag_cmlp_once(cfg):
    def _run(Xtr, ytr, Xte, yte):
        # carve a validation split out of the training fold (90/10)
        n = len(Xtr); idx = np.random.permutation(n); cut = int(0.9 * n)
        tr, va = idx[:cut], idx[cut:]
        model = TAGCMLP(cfg).fit(Xtr[tr], ytr[tr], Xtr[va], ytr[va])
        out = model.predict(Xte, yte)
        return classification_metrics(yte, out["pred"], out["prob"], out["rel"])
    return _run


def run_baseline_once(fit, prob):
    def _run(Xtr, ytr, Xte, yte):
        m = fit(Xtr, ytr); p = prob(m, Xte)
        pred = (p > 0.5).astype(int)
        return classification_metrics(yte, pred, p)
    return _run


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", choices=["pass_fail", "pass_withdrawn"],
                    default="pass_fail")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    cfg = load_config(args.config)
    os.makedirs(args.out, exist_ok=True)

    data = load_oulad(cfg["data"]["oulad_dir"])
    metric_cols = ["ACC", "PRE", "REC", "F1", "AUC", "REL"]
    folds = cfg["evaluation"]["folds"]; seeds = cfg["evaluation"]["seeds"]

    for w in cfg["early_prediction"]["cutoff_weeks"]:
        ids, X, y = build_sequences(data, args.task, w,
                                    cfg["early_prediction"]["bin_days"])
        print(f"\n=== Task={args.task}  Week {w}  N={len(y)}  T={X.shape[1]} ===")

        # TAG-CMLP
        df = cross_validate(run_tag_cmlp_once(cfg), X, y, folds, seeds)
        df["model"] = "TAG-CMLP"; df["week"] = w
        all_runs = [df]

        # baselines
        for name, (fit, prob) in get_baselines().items():
            cols = [c for c in metric_cols if c != "REL"]
            d = cross_validate(run_baseline_once(fit, prob), X, y, folds, seeds)
            d["model"] = name; d["week"] = w
            all_runs.append(d)

        runs = pd.concat(all_runs, ignore_index=True)
        runs.to_csv(os.path.join(args.out, f"{args.task}_week{w}_runs.csv"),
                    index=False)

        # summary table (mean +/- s.d. + 95% CI) per model
        summ = []
        for model, g in runs.groupby("model"):
            s = summarise(g, [c for c in metric_cols if c in g], cfg["evaluation"]["ci"])
            s["model"] = model; summ.append(s.reset_index().rename(
                columns={"index": "metric"}))
        pd.concat(summ).to_csv(
            os.path.join(args.out, f"{args.task}_week{w}_summary.csv"), index=False)
        print(runs.groupby("model")["ACC"].agg(["mean", "std"]).round(2))

    print(f"\nDone. Results in ./{args.out}/")


if __name__ == "__main__":
    main()
