"""Significance testing and critical-difference diagram from saved per-run scores.

Usage:
    python -m scripts.run_significance --results results/pass_fail_week30_runs.csv
"""
import argparse, os
import numpy as np
import pandas as pd

from src.evaluation import (compare_to_baselines, friedman_nemenyi,
                            plot_cd_diagram)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True,
                    help="CSV produced by run_early_prediction (one row per run).")
    ap.add_argument("--metric", default="ACC")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    df = pd.read_csv(args.results)
    # align runs by (seed, fold) so comparisons are paired
    pivot = df.pivot_table(index=["seed", "fold"], columns="model",
                           values=args.metric)
    pivot = pivot.dropna(axis=0)
    models = list(pivot.columns)
    assert "TAG-CMLP" in models, "TAG-CMLP column missing"

    model_scores = pivot["TAG-CMLP"].values
    baseline_scores = {m: pivot[m].values for m in models if m != "TAG-CMLP"}

    sig = compare_to_baselines(model_scores, baseline_scores)
    sig.to_csv(os.path.join(args.out, "significance.csv"), index=False)
    print("\nPairwise significance (Wilcoxon, Holm-corrected):")
    print(sig.round(4).to_string(index=False))

    ranks, fried_p, cd = friedman_nemenyi(pivot.values, models)
    print(f"\nFriedman p = {fried_p:.3e}   Nemenyi CD = {cd:.3f}")
    print("Mean ranks:\n", ranks.round(3).to_string())
    path = plot_cd_diagram(ranks, cd, os.path.join(args.out, "cd_diagram.png"))
    print(f"CD diagram saved to {path}")


if __name__ == "__main__":
    main()
